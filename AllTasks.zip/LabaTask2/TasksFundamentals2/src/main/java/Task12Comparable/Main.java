package Task12Comparable;

/**
 * Created by Iryna_Filipava1 on 10/3/2016.
 */
public class Main {

    public static void main(String[] args) {

        BookSort isbnnumber = new BookSort();
        isbnnumber.getListofBook();
        isbnnumber.sortListIsbn();
    }
}
