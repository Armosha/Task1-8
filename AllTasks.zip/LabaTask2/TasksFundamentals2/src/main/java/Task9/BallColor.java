package Task9;

/**
 * Created by Iryna_Filipava1 on 10/3/2016.
 */
public enum BallColor {
    RED,
    YELLOW,
    GREEN,
    BLUE
}
