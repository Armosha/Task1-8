package basesax;

public enum MenuTagName {
    TYPE,
    PHOTO,
    NAME,
    DESCRIPTION,
    PORTION,
    PRICE,
    VALUE,
    DISH,
    OPTION,
    DISHES
}