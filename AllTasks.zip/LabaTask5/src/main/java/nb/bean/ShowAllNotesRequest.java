package nb.bean;


public class ShowAllNotesRequest extends Request {
    private int userId;

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
}
