package nb.bean;

/**
 * Created by Iryna Filipava on 06.10.2016.
 */
public class FindByDateRequest extends Request {

    private String day;
    private String month;
    private String year;
    private int userId;

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
}