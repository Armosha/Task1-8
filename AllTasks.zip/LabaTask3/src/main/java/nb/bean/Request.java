package nb.bean;

/**
 * Created by Iryna Filipava on 06.10.2016.
 */

public class Request {
	private String commandName;

	public String getCommandName() {
		return commandName;
	}

	public void setCommandName(String commandName) {
		this.commandName = commandName;
	}

}
