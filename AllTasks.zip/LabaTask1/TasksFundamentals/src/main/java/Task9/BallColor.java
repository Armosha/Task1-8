/*package Task9;


public enum BallColor {
    BLUE("Blue"),
    RED("Red"),
    YELLOW("Yellow"),
    GREEN("Green");

    String colorname;

    BallColor(String color) {
        color = colorname;
    }
}
*/